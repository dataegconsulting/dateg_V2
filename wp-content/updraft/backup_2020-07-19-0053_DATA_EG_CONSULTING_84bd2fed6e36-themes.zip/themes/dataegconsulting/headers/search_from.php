<div class="searchFixed popupBG">
        <div class="container-fluid">
            <a href="" id="sfCloser" class="sfCloser"></a>
            <div class="searchForms">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <form method="post" action="#">
                                <input type="text" name="s" class="searchField" placeholder="Buscar..."/>
                                <button type="submit"><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>