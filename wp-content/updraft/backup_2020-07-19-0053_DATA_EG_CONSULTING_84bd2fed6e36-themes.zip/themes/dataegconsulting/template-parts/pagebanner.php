<section class="pageBanner">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="banner_content text-center"> 
                    <h2><?php the_title();?> </h2>
                </div>
            </div>
        </div>
    </div>
</section>